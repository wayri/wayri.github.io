# Licensing

KiCad WebView's owner-authored software is licensed under the **Mozilla Public License 2.0 (MPL-2.0)**. Copyright © 2026 wayri. The unmodified [LICENSE](LICENSE) is authoritative. Commercial use, sale, self-hosting and integration into proprietary applications are permitted; individual approval is not required.

## Distribution and modifications

MPL applies at the source-file level. When distributing covered software, keep its license notices and make the covered source, including your modifications, available as required by MPL. Separate host-application files do not become MPL merely because they use this library. MPL does not require you to submit a pull request, and it does not prevent paid competing offerings.

Minified JavaScript and bundled HTML are not the preferred form for editing the library. Tell recipients where to obtain the corresponding source. The exact matching source revision is recorded in each build's source banner and release metadata; obtain that revision from the [public source repository](https://github.com/wayri/kicad-webview). Keep the source link, LICENSE, THIRD-PARTY-NOTICES.md and dependency notices with distributed builds. If you modify a build, supply your matching modified covered source rather than pointing only to an unmodified upstream release. The build scripts carry this source offer in their banners and distribution metadata.

## Scope and exceptions

- Three.js and fzstd retain their MIT licenses and credits. Other external dependencies retain their own terms; see [third-party notices](THIRD-PARTY-NOTICES.md).
- The Forge integration uses external Atlassian packages under their supplied terms. MPL covers our adapter code, not Atlassian's SDK or services.
- The KERO Encoder PCB, schematics and fabrication examples are separately authorized demonstration data, **not an open-hardware grant**. Their provenance and redistribution conditions remain in fixtures/kero-encoder and fixtures/kero-encoder-cam. The software license does not license users' designs, model libraries or analysis results.
- This grant covers the owner-authored subset supplied here, not the rest of SPIKE, Pocket KiView or other parent projects. Historical extraction identities and hashes remain in SOURCE-PROVENANCE.json.
- Earlier source-available copies retain their valid grants. Texts in licenses/ are historical unless a dependency notice explicitly applies them; they impose no additional commercial restriction on the software released here under MPL.

## Brand and contributions

The code license does not grant rights to impersonate the project or imply endorsement. See [project name policy](TRADEMARKS.md). Contributors retain copyright and submit their contributions under MPL-2.0; no copyright assignment or proprietary relicensing permission is implied. See [contributing](CONTRIBUTING.md).

The library is free to use, including commercially, under MPL-2.0. No payment or individual commercial-use approval is required. Need help embedding or customizing KiCad WebView? Optional paid implementation, maintenance, and support are available at [support.kivi@sigharmonic.com](mailto:support.kivi@sigharmonic.com). You do not need to buy these services to use or integrate the library. Paid services do not change the open-source license. For explanatory guidance, see the [Mozilla MPL FAQ](https://www.mozilla.org/en-US/MPL/2.0/FAQ/).
